import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:untitled4/util/app_color.dart';
import 'package:untitled4/util/app_text_style.dart';
import 'package:untitled4/util/custom_button.dart';




class SecondPage extends StatefulWidget {
  const SecondPage({Key? key}) : super(key: key);

  @override
  State<SecondPage> createState() => _SecondPageState();
}

class _SecondPageState extends State<SecondPage> {
  @override
  Widget build(BuildContext context) {

    return Scaffold(
        appBar: AppBar(
          backgroundColor: AppColor.whiteColor,
          elevation: 5,
          centerTitle: false,
          title: Text("Sotuv",
              style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w600,
                  color: Colors.black)),
          actions: [
            Padding(
              padding: const EdgeInsets.only(top: 18, right: 15),
              child: Text("BEKOR QILISH",
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      color: Color(0xff4044C8))),
            ),
          ],
          leading: Row(
            children: [
              IconButton(
                onPressed: () {},
                icon: Icon(Icons.arrow_back),
                iconSize: 30,
                color: AppColor.blackColor,
              ),
            ],
          ),
        ),
        body: Column(children: [
          Padding(
            padding: const EdgeInsets.only(top: 15, left: 15),
            child: Row(children: [
              Row(children: [
                ElevatedButton.icon(
                  label: Text("Hudud"),
                  icon: Icon(Icons.keyboard_arrow_down),
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(
                      Radius.circular(15),
                    )),
                    primary: Color(0xff4044C8),
                    fixedSize: Size(173, 26),
                  ),
                )
              ]),
              SizedBox(
                width: 15,
              ),
              ElevatedButton.icon(
                label: Text("Narx filtri"),
                icon: Icon(Icons.keyboard_arrow_down),
                onPressed: () {},
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(
                    Radius.circular(15),
                  )),
                  primary: Color(0xff4044C8),
                  fixedSize: Size(173, 26),
                ),
              ),
            ]),
          ),
          SizedBox(
            height: 15,
          ),
          Row(
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 10),
                child: SizedBox(
                  width: 173,
                  child: TextField(
                    decoration: InputDecoration(
                        border: UnderlineInputBorder(),
                        hintText: "\$                             dan",
                        hintStyle: AppTypography.h6filtrText),
                  ),
                ),
              ),
              SizedBox(
                width: 15,
              ),
              SizedBox(
                width: 173,
                child: TextField(
                  decoration: InputDecoration(
                      border: UnderlineInputBorder(),
                      hintText: "\$                         gacha",
                      hintStyle: AppTypography.h6filtrText),
                ),
              ),
            ],
          ),
          SizedBox(
            height: 15,
          ),
          Padding(
            padding: const EdgeInsets.only(left: 10),
            child: Row(
              children: [
                Text("Narxi pasaytirilgan", style: AppTypography.h6filtrText),
                SizedBox(
                  width: 2,
                ),
                Icon(
                  Icons.crop_din,
                  size: 18,
                ),
                SizedBox(
                  width: 8,
                ),
                Text(
                  "Kami bor",
                  style: AppTypography.h6filtrText,
                ),
                SizedBox(
                  width: 2,
                ),
                Icon(
                  Icons.crop_din,
                  size: 18,
                ),
                SizedBox(
                  width: 8,
                ),
                Text(
                  "Variantga",
                  style: AppTypography.h6filtrText,
                ),
                SizedBox(
                  width: 2,
                ),
                Icon(
                  Icons.crop_din,
                  size: 18,
                ),
              ],
            ),
          ),
          SizedBox(
            height: 25,
          ),
          CustomButton(
              title: "E'lonlarni ko'rsatish",
              onTap: () {},
              height: 39,
              color: AppColor.appColor,
              width: 351),
      SizedBox(height: 20,),
    SingleChildScrollView(
   child: Padding(
    padding: const EdgeInsets.only(left: 10,right: 10),
    child: Container(
    width: 451,
    height: 188,
    color: AppColor.cardColor,
    child: Row(
    children: [
    Image.asset("images/dormitory.jpg"),
    SizedBox(width: 10,),
    Padding(
    padding: const EdgeInsets.only(top: 15),
    child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
    Text(
    "27 000 \$",
    style: AppTypography.h3CardbigText,
    ),
    SizedBox(height: 10,),
    Row(
    children: [
    CircleAvatar(
    backgroundColor: AppColor.appColor,
    radius: 5,
    ),
    SizedBox(width: 5,),
    Text(
    "2 xonali kvartira",
    style: AppTypography.h1AppText,
    ),
    ],
    ),
    SizedBox(height: 10,),
    Row(
    children: [
    CircleAvatar(
    backgroundColor: AppColor.appColor,
    radius: 5,
    ),
    SizedBox(width: 5,),
    Text("4-qavat",style: AppTypography.h1AppText,),

    ],
    ),
    SizedBox(height: 10,),
    Row(
    children: [
    CircleAvatar(
    backgroundColor: AppColor.appColor,
    radius: 5,
    ),
    SizedBox(width: 5,),
    Text("37m",style: AppTypography.h1AppText,),
    ],
    ),
    SizedBox(height: 10,),
    Row(
    children: [
    Image.asset("images/underground.jpg",width: 15,height: 15,),
    Text("Oybek",style: AppTypography.h1AppText,),
    ],
    ),
    SizedBox(height: 10,),
    Row(
    children: [
    Text(
    "Manzil:",
    style: TextStyle(fontWeight: FontWeight.bold),
    ),
    Text("Toshken shahri")
    ],
    ),
    Text("Chilonzor tumani"),

    ],

    ),

    ),
        ],

        ),

    ),

    ),

    ),
    SizedBox(height: 15,),
    Padding(
    padding: const EdgeInsets.only(left: 10,right: 10),
    child: Container(
    width: 451,
    height: 188,
    color: AppColor.cardColor,
    child: Row(
    children: [
    Image.asset("images/hihome.jpg"),
    SizedBox(width: 10,),
    Padding(
    padding: const EdgeInsets.only(top: 15),
    child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
    Text(
    "30 000 \$",
    style: AppTypography.h3CardbigText,
    ),
    SizedBox(height: 10,),
    Row(
    children: [
    CircleAvatar(
    backgroundColor: AppColor.appColor,
    radius: 5,
    ),
    SizedBox(width: 5,),
    Text(
    "2 xonali kvartira",
    style: AppTypography.h1AppText,
    ),
    ],
    ),
    SizedBox(height: 10,),
    Row(
    children: [
    CircleAvatar(
    backgroundColor: AppColor.appColor,
    radius: 5,
    ),
    SizedBox(width: 5,),
    Text("4-qavat",style: AppTypography.h1AppText,),

    ],
    ),
    SizedBox(height: 10,),
    Row(
    children: [
    CircleAvatar(
    backgroundColor: AppColor.appColor,
    radius: 5,
    ),
    SizedBox(width: 5,),
    Text("37m",style: AppTypography.h1AppText,),
    ],
    ),
    SizedBox(height: 10,),
    Row(
    children: [
    Image.asset("images/underground.jpg",width: 15,height: 15,),
    Text("Oybek",style: AppTypography.h1AppText,),
    ],
    ),
    SizedBox(height: 10,),
    Row(
    children: [
    Text(
    "Manzil:",
    style: TextStyle(fontWeight: FontWeight.bold),
    ),
    Text("Toshken shahri")
    ],
    ),
    Text("Chilonzor tumani"),

    ],
    ),

    )
       ]
        )
    )
    )
        ]
        )
    );
  }
}
