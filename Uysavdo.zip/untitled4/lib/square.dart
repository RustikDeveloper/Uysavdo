import 'package:flutter/cupertino.dart';
import 'package:untitled4/util/app_color.dart';

class MySquare extends StatelessWidget {
  const MySquare({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 15),
      child: Container(
            height: 188,
            width: 351,
            color: AppColor.cardColor,
          ),
    );
  }
}
