import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:untitled4/square.dart';
import 'package:untitled4/util/app_color.dart';
import 'package:untitled4/util/app_text_style.dart';

class FirstPage extends StatefulWidget {
  final List _list = ['post', 'post1', 'post2'];

  // const FirstPage({Key? key}) : super(key: key);

  @override
  State<FirstPage> createState() => _FirstPageState();
}

class _FirstPageState extends State<FirstPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SingleChildScrollView(
      child: Container(
        child: Column(children: [
          Row(
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 48, left: 10),
                child: Image.asset("images/logo2.png"),
              ),
              SizedBox(
                width: 46,
              ),
              Padding(
                padding: const EdgeInsets.only(top: 48),
                child: Image.asset("images/telegram.png"),
              ),
              SizedBox(
                width: 10,
              ),
              Padding(
                padding: const EdgeInsets.only(top: 48),
                child: Text(
                  "Telegram",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                ),
              ),
              SizedBox(
                width: 10,
              ),
              Padding(
                padding: const EdgeInsets.only(top: 48),
                child: Text(
                  "kanaliga o'tish",
                  style: TextStyle(fontWeight: FontWeight.w400, fontSize: 16),
                ),
              )
            ],
          ),
          SizedBox(
            height: 24,
          ),
          Image.asset("images/bed.jpg"),
          SizedBox(
            height: 15,
          ),
          Padding(
            padding: const EdgeInsets.only(left: 10),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              ElevatedButton(
                onPressed: () {},
                child: Text("Sotuv"),
                style: ElevatedButton.styleFrom(
                  fixedSize: Size(112, 32),
                  primary: Colors.blue[200],
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ),
              SizedBox(
                width: 15,
              ),
              ElevatedButton(
                  onPressed: () {},
                  child: Text("Ijara"),
                  style: ElevatedButton.styleFrom(
                      fixedSize: Size(112, 32),
                      primary: Colors.blue[200],
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ))),
              SizedBox(
                width: 10,
              ),
              ElevatedButton(
                  onPressed: () {},
                  child: Text("Video obzor"),
                  style: ElevatedButton.styleFrom(
                      fixedSize: Size(112, 32),
                      primary: Colors.blue[200],
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ))),
            ]),
          ),
          SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.only(left: 10),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ElevatedButton.icon(
                  onPressed: () {},
                  icon: Image.asset("images/kv.png"),
                  style: ElevatedButton.styleFrom(
                    primary: Color(0xffE9F2FB),
                    fixedSize: Size(173, 45),
                  ),
                  label: Text(
                    "Kvartira",
                    style: TextStyle(color: Colors.black87),
                  ),
                ),
                SizedBox(
                  width: 10,
                ),
                ElevatedButton.icon(
                  onPressed: () {},
                  icon: Image.asset("images/home.png"),
                  style: ElevatedButton.styleFrom(
                    primary: Color(0xffE9F2FB),
                    fixedSize: Size(173, 45),
                  ),
                  label: Text(
                    "Hovli",
                    style: TextStyle(color: Colors.black87),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 15,
          ),
          Padding(
            padding: const EdgeInsets.only(left: 10),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ElevatedButton.icon(
                  onPressed: () {},
                  icon: Image.asset("images/ground.png"),
                  style: ElevatedButton.styleFrom(
                    primary: Color(0xffE9F2FB),
                    fixedSize: Size(173, 45),
                  ),
                  label: Text(
                    "Quruq yer",
                    style: TextStyle(color: Colors.black87),
                  ),
                ),
                SizedBox(
                  width: 10,
                ),
                ElevatedButton.icon(
                  onPressed: () {},
                  icon: Image.asset("images/office.png"),
                  style: ElevatedButton.styleFrom(
                    primary: Color(0xffE9F2FB),
                    fixedSize: Size(173, 45),
                  ),
                  label: Text(
                    "Ofis/Noturar",
                    style: TextStyle(color: Colors.black87),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 15,
          ),
          Padding(
              padding: const EdgeInsets.only(right: 18),
              child: ElevatedButton.icon(
                onPressed: () {},
                icon: Image.asset("images/newb.png"),
                style: ElevatedButton.styleFrom(
                  primary: Color(0xffE9F2FB),
                  fixedSize: Size(351, 45),
                ),
                label: Text(
                  "Yangi inshootlar",
                  style: TextStyle(color: Colors.black87),
                ),
              )),
          SizedBox(
            height: 25,
          ),
           Padding(
             padding: const EdgeInsets.only(left: 10,right: 10),
             child: Container(
                width: 451,
                height: 188,

                color: AppColor.cardColor,
                child: Row(
                  children: [
                    Image.asset("images/hihome.jpg"),
                    SizedBox(width: 10,),
                    Padding(
                      padding: const EdgeInsets.only(top: 15),
                      child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "30 000 \$",
                            style: AppTypography.h3CardbigText,
                          ),
                      SizedBox(height: 10,),
                          Row(
                            children: [
                              CircleAvatar(
                                backgroundColor: AppColor.appColor,
                                radius: 5,
                              ),
                              SizedBox(width: 5,),
                              Text(
                                "2 xonali kvartira",
                                style: AppTypography.h1AppText,
                              ),
                            ],
                          ),
                          SizedBox(height: 10,),
                          Row(
                            children: [
                              CircleAvatar(
                                backgroundColor: AppColor.appColor,
                                radius: 5,
                              ),
                              SizedBox(width: 5,),
                              Text("4-qavat",style: AppTypography.h1AppText,),

                            ],
                          ),
                          SizedBox(height: 10,),
                          Row(
                            children: [
                              CircleAvatar(
                                backgroundColor: AppColor.appColor,
                                radius: 5,
                              ),
                              SizedBox(width: 5,),
                              Text("37m",style: AppTypography.h1AppText,),
                            ],
                          ),
                          SizedBox(height: 10,),
                          Row(
                            children: [
                              Image.asset("images/underground.jpg",width: 15,height: 15,),
                              Text("Oybek",style: AppTypography.h1AppText,),
                            ],
                          ),
                          SizedBox(height: 10,),
                          Row(
                            children: [
                              Text(
                                "Manzil:",
                                style: TextStyle(fontWeight: FontWeight.bold),
                              ),
                              Text("Toshken shahri")
                            ],
                          ),
                          Text("Chilonzor tumani"),

                        ],
                        
                      ),
                    ),
                  ],
                ),

              ),


           ),
          SizedBox(height: 15,),
          Padding(
            padding: const EdgeInsets.only(left: 10,right: 10),
            child: Container(
              width: 451,
              height: 188,
              color: AppColor.cardColor,
              child: Row(
                children: [
                  Image.asset("images/tables.jpg"),
                  SizedBox(width: 10,),
                  Padding(
                    padding: const EdgeInsets.only(top: 15),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "24 000 \$",
                          style: AppTypography.h3CardbigText,
                        ),
                        SizedBox(height: 10,),
                        Row(
                          children: [
                            CircleAvatar(
                              backgroundColor: AppColor.appColor,
                              radius: 5,
                            ),
                            SizedBox(width: 5,),
                            Text(
                              "2 xonali kvartira",
                              style: AppTypography.h1AppText,
                            ),
                          ],
                        ),
                        SizedBox(height: 10,),
                        Row(
                          children: [
                            CircleAvatar(
                              backgroundColor: AppColor.appColor,
                              radius: 5,
                            ),
                            SizedBox(width: 5,),
                            Text("4-qavat",style: AppTypography.h1AppText,),

                          ],
                        ),
                        SizedBox(height: 10,),
                        Row(
                          children: [
                            CircleAvatar(
                              backgroundColor: AppColor.appColor,
                              radius: 5,
                            ),
                            SizedBox(width: 5,),
                            Text("37m",style: AppTypography.h1AppText,),
                          ],
                        ),
                        SizedBox(height: 10,),
                        Row(
                          children: [
                            Image.asset("images/underground.jpg",width: 15,height: 15,),
                            Text("Oybek",style: AppTypography.h1AppText,),
                          ],
                        ),
                        SizedBox(height: 10,),
                        Row(
                          children: [
                            Text(
                              "Manzil:",
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            Text("Toshken shahri")
                          ],
                        ),
                        Text("Chilonzor tumani"),

                          ],
                        )



                    ),



                ],
              ),

            ),

          ),

          SizedBox(
            height: 25,
          ),
          Padding(
            padding: const EdgeInsets.only(left: 10,right: 10),
            child: Container(
              width: 451,
              height: 188,
              color: AppColor.cardColor,
              child: Row(
                children: [
                  Image.asset("images/dormitory.jpg"),
                  SizedBox(width: 10,),
                  Padding(
                    padding: const EdgeInsets.only(top: 15),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "27 000 \$",
                          style: AppTypography.h3CardbigText,
                        ),
                        SizedBox(height: 10,),
                        Row(
                          children: [
                            CircleAvatar(
                              backgroundColor: AppColor.appColor,
                              radius: 5,
                            ),
                            SizedBox(width: 5,),
                            Text(
                              "2 xonali kvartira",
                              style: AppTypography.h1AppText,
                            ),
                          ],
                        ),
                        SizedBox(height: 10,),
                        Row(
                          children: [
                            CircleAvatar(
                              backgroundColor: AppColor.appColor,
                              radius: 5,
                            ),
                            SizedBox(width: 5,),
                            Text("4-qavat",style: AppTypography.h1AppText,),

                          ],
                        ),
                        SizedBox(height: 10,),
                        Row(
                          children: [
                            CircleAvatar(
                              backgroundColor: AppColor.appColor,
                              radius: 5,
                            ),
                            SizedBox(width: 5,),
                            Text("37m",style: AppTypography.h1AppText,),
                          ],
                        ),
                        SizedBox(height: 10,),
                        Row(
                          children: [
                            Image.asset("images/underground.jpg",width: 15,height: 15,),
                            Text("Oybek",style: AppTypography.h1AppText,),
                          ],
                        ),
                        SizedBox(height: 10,),
                        Row(
                          children: [
                            Text(
                              "Manzil:",
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            Text("Toshken shahri")
                          ],
                        ),
                        Text("Chilonzor tumani"),
                       
                      ],

                    ),
                    
                  )
                ],
              ),
            ),
          ),








        ]
        ),
      ),
    ));
  }
}
