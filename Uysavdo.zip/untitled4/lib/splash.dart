import 'dart:async';

import 'package:flutter/material.dart';
import 'package:untitled4/first.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState(){
super.initState();
Timer(const Duration(seconds: 5), () {
  Navigator.push(context,MaterialPageRoute(builder: (BuildContext contex)=>FirstPage()));
});

  }


  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff4044C8),
          body: Center(child: Image.asset("images/logo.png"))










      );





  }
}
