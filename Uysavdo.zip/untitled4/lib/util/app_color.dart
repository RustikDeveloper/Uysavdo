import 'dart:ui';

class AppColor {

  static const appColor = Color(0xff4044C8);
  static const whiteColor = Color(0xffFFFFFF);
  static const cardColor = Color(0xffE9F2FB);
  static const blackColor = Color(0xff000000);
  static const buttonlightColor = Color(0xffCBE6FA);
  static const greenColor = Color(0xff249D3F);
  static const redColor = Color(0xffD6492D);

}