


import 'package:flutter/material.dart';
import 'package:untitled4/util/app_color.dart';

const h1_TextSize = 10.0;
const h2_TextSize = 11.0;
const h3_TextSzie =14.0;
const h4_TextSize = 18.0;
const h5_TextSize = 16.0;


const _h1TextLineHeight =   11.93;


class  AppTypography {

static const h1AppText = TextStyle(
  fontWeight: FontWeight.w400,
  fontSize: h1_TextSize,
  color: AppColor.blackColor,

    );
static const h2CardText= TextStyle(
  fontWeight: FontWeight.w400,
  fontSize: h1_TextSize,
  color: AppColor.blackColor,

);
static const h3CardbigText= TextStyle(
  fontWeight: FontWeight.w700,
  fontSize: h4_TextSize,
  color: AppColor.appColor,

);
static const h4ButtonText= TextStyle(
  fontWeight: FontWeight.w600,
  fontSize: h4_TextSize,
  color: AppColor.whiteColor

);
static const h5AppBarText= TextStyle(
  fontWeight: FontWeight.w600,
  fontSize: h5_TextSize,
  color: AppColor.blackColor,

);
static const h6filtrText = TextStyle(
  fontWeight: FontWeight.w400,
  fontSize: h4_TextSize,
  color: AppColor.blackColor
);



}