import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class CustomButton extends StatelessWidget {
  const CustomButton(
      {Key? key,
      required this.title,
      required this.onTap,
      required this.height,
      required this.color, required this.width})
      : super(key: key);
  final String title;
  final GestureTapCallback onTap;
  final double height;
  final double width;
  final Color color;


  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      width: width,
      color: color,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(primary: color,
        shape: RoundedRectangleBorder(borderRadius:BorderRadius.all(Radius.circular(15)
        )
        )
        ),
        onPressed: () {},
        child: Row(
          children: [Text(title)],
        ),

      ),

    );
  }
}
