import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:untitled4/util/app_color.dart';

class ThirdPage extends StatefulWidget {
  const ThirdPage({Key? key}) : super(key: key);

  @override
  State<ThirdPage> createState() => _ThirdPageState();
}

class _ThirdPageState extends State<ThirdPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColor.whiteColor,
        elevation: 5,
        centerTitle: false,
        title: Text("12 000\$",
            style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w600,
                color: Colors.black)),
        actions: [
          Padding(
            padding: const EdgeInsets.only(top: 18, right: 15),
            child: Icon(Icons.favorite_border,color: AppColor.blackColor,),
            
          ),
          Padding(
            padding: const EdgeInsets.only(top: 18, right: 15),
            child: Icon(Icons.share,color: AppColor.blackColor,),
          )
        ],
        leading: Row(
          children: [
            IconButton(
              onPressed: () {},
              icon: Icon(Icons.arrow_back),
              iconSize: 30,
              color: AppColor.blackColor,
            ),
          ],
        ),

      ),
body: Column(
  children: [
    Padding(
      padding: const EdgeInsets.only(left: 10,top: 10),
      child: Image.asset("images/hihome.jpg",height: 227,width: 375,fit: BoxFit.fill,),
    )
  ],
),







    );
  }
}
