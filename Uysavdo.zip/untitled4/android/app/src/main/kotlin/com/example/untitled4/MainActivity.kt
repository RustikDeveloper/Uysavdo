package com.example.untitled4

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
